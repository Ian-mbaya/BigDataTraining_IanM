import boto3

def lambda_handler(event, context):
    glue = boto3.client('glue')
    
    # List of crawler names
    crawlers = ['etfcrawler', 'holdingscrawler', 'etfanalysis']
    
    # Trigger each crawler
    for crawler in crawlers:
        try:
            response = glue.start_crawler(Name=crawler)
            print(f"Started crawler: {crawler}", response)
        except Exception as e:
            print(f"Failed to start crawler: {crawler}", str(e))
    
    return {
        'statusCode': 200,
        'body': 'All crawlers have been triggered.'
    }
