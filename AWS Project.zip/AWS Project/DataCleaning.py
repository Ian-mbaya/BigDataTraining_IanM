import boto3
import pandas as pd
import io
import json

def lambda_handler(event, context):
    # Initialize S3 client
    s3 = boto3.client('s3')
    bucket_name = 'ian5774'  
    input_prefix = 'rawbronze/etfdata/'   
    holdings_folder = 'stagingsilver/holdings/'     
    etf_transformed = 'stagingsilver/etfTransformed/'  
    
    # Define the correct column names from the schema you provided
    column_names = [
        'fund_symbol', 'fund_long_name', 'fund_category', 'fund_family', 'exchange_code', 'exchange_name',
        'avg_vol_3month', 'total_net_assets', 'fund_yield', 'inception_date', 'investment_type', 'size_type',
        'fund_price_earning_ratio', 'fund_price_sales_ratio', 'top10_holdings_total_assets',
        'fund_return_ytd', 'fund_return_3years', 'fund_return_10years',
        'holding1_name', 'holding1_value', 'holding2_name', 'holding2_value', 'holding3_name', 'holding3_value',
        'holding4_name', 'holding4_value', 'holding5_name', 'holding5_value', 'holding6_name', 'holding6_value',
        'holding7_name', 'holding7_value', 'holding8_name', 'holding8_value', 'holding9_name', 'holding9_value',
        'holding10_name', 'holding10_value', 'timestamp'
    ]
    
    # Get list of objects in the specified S3 folder
    response = s3.list_objects_v2(Bucket=bucket_name, Prefix=input_prefix)
    
    if 'Contents' not in response:
        return {"status": "No files found in the specified S3 folder."}

    # Read the data files
    dataframes = []
    for obj in response['Contents']:
        file_key = obj['Key']
        if file_key.endswith('.json'):
            file_obj = s3.get_object(Bucket=bucket_name, Key=file_key)
            json_content = file_obj['Body'].read().decode('utf-8')
            try:
                # Load data and assign the correct columns
                data = json.loads(json_content)
                df = pd.DataFrame(data, columns=column_names)  # Assign the correct column names here
                dataframes.append(df)
            except json.JSONDecodeError:
                print(f"Error decoding JSON for file: {file_key}")
    
    if not dataframes:
        return {"status": "No valid data found."}
    
    # Concatenate all dataframes
    data = pd.concat(dataframes, ignore_index=True)

    # Log the column names and the first few rows of the data
    print(f"Data Columns: {list(data.columns)}")
    print(f"Sample Data: {data.head()}")

    # Drop all the holding columns from the ETF data
    holding_columns = [
        'holding1_name', 'holding1_value', 'holding2_name', 'holding2_value', 'holding3_name', 'holding3_value',
        'holding4_name', 'holding4_value', 'holding5_name', 'holding5_value', 'holding6_name', 'holding6_value',
        'holding7_name', 'holding7_value', 'holding8_name', 'holding8_value', 'holding9_name', 'holding9_value',
        'holding10_name', 'holding10_value'
    ]
    
    # Drop these columns from the data (etf_transformed)
    etf_transformed_df = data.drop(columns=holding_columns, errors='ignore')

    # Log the final ETF DataFrame after dropping holding columns
    print(f"ETF Transformed DataFrame (after dropping holding columns): {etf_transformed_df.head()}")  # <-- Fixed here
    
    # Write the updated etf_transformed dataframe to S3
    etfdata_csv_buffer = io.StringIO()
    etf_transformed_df.to_csv(etfdata_csv_buffer, index=False)
    s3.put_object(Bucket=bucket_name, Key=f'{etf_transformed}etf_data.csv', Body=etfdata_csv_buffer.getvalue())

    # Handle holdings file separately (if needed)
    holdings_list = []
    max_holdings = 10

    for i in range(1, max_holdings + 1):
        name_col = f'holding{i}_name'
        value_col = f'holding{i}_value'

        if name_col in data.columns and value_col in data.columns:
            temp_holdings = data[[name_col, value_col]].copy()
            temp_holdings['fund_symbol'] = data['fund_symbol']
            temp_holdings.columns = ['holding_name', 'holding_value', 'fund_symbol']

            temp_holdings = temp_holdings.dropna(subset=['holding_name', 'holding_value'])
            temp_holdings = temp_holdings[temp_holdings['holding_value'] != 0]

            if not temp_holdings.empty:
                holdings_list.append(temp_holdings)

    if holdings_list:
        holdings_df = pd.concat(holdings_list, ignore_index=True)
        holdings_df = holdings_df[['fund_symbol', 'holding_name', 'holding_value']]

        # Write holdings dataframe to S3
        holdings_csv_buffer = io.StringIO()
        holdings_df.to_csv(holdings_csv_buffer, index=False)
        s3.put_object(Bucket=bucket_name, Key=f'{holdings_folder}holdings_data.csv', Body=holdings_csv_buffer.getvalue())
    else:
        print("No holdings found; creating empty holdings DataFrame.")
        holdings_df = pd.DataFrame(columns=['fund_symbol', 'holding_name', 'holding_value'])

    return {"status": "Data processed and stored successfully."}
