import boto3
import json

# Create a DynamoDB client
dynamodb = boto3.client('dynamodb')

# Define the table creation logic
def create_dynamodb_table():
    table_name = 'SNStable'
    
    try:
        # Create the DynamoDB table
        response = dynamodb.create_table(
            TableName=table_name,
            KeySchema=[
                {
                    'AttributeName': 'trade_id',
                    'KeyType': 'HASH'  # Partition key
                }
            ],
            AttributeDefinitions=[
                {
                    'AttributeName': 'trade_id',
                    'AttributeType': 'N'  # Numeric type for trade_id
                }
            ],
            ProvisionedThroughput={
                'ReadCapacityUnits': 5,
                'WriteCapacityUnits': 5
            }
        )
        print(f"Creating table {table_name}...")
        
        # Wait for the table to be created before proceeding
        dynamodb.get_waiter('table_exists').wait(TableName=table_name)
        print(f"Table {table_name} is created and ready to use.")
        
        return {
            'statusCode': 200,
            'body': json.dumps(f"Table {table_name} created successfully!")
        }
    
    except dynamodb.exceptions.ResourceInUseException:
        print(f"Table {table_name} already exists.")
        return {
            'statusCode': 400,
            'body': json.dumps(f"Table {table_name} already exists.")
        }
    
    except Exception as e:
        print(f"Error creating DynamoDB table: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error creating table: {e}")
        }

# Lambda handler function
def lambda_handler(event, context):
    return create_dynamodb_table()
