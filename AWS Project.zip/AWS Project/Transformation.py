import boto3
import pandas as pd
import io
import json
from datetime import datetime

def lambda_handler(event, context):
    # Initialize S3 client
    s3 = boto3.client('s3')
    bucket_name = 'ian5774'
    input_prefix = 'rawbronze/etfprices/'  
    output_prefix = 'stagingsilver/priceanalysis/'  
    
    # Get list of objects in the specified S3 folder
    response = s3.list_objects_v2(Bucket=bucket_name, Prefix=input_prefix)
    
    if 'Contents' not in response:
        return {"status": "No files found in the specified S3 folder."}

    # Read the data files
    dataframes = []
    for obj in response['Contents']:
        file_key = obj['Key']
        if file_key.endswith('.csv'):
            file_obj = s3.get_object(Bucket=bucket_name, Key=file_key)
            csv_content = file_obj['Body'].read().decode('utf-8')
            df = pd.read_csv(io.StringIO(csv_content))  # Load CSV to pandas DataFrame
            dataframes.append(df)
    
    # Concatenate all dataframes
    if not dataframes:
        return {"status": "No valid CSV files found."}

    data = pd.concat(dataframes, ignore_index=True)
    
    # Log the first few records and columns to inspect the structure
    print(f"Columns in the data: {data.columns.tolist()}")
    print(f"Sample data: {data.head(5).to_dict()}")  # Log the first 5 records for inspection
    
    
    # Check if 'price_date' column exists
    if 'price_date' not in data.columns:
        return {"status": "'price_date' column not found in the data. Please check the structure of the JSON files."}

    # Filter out rows where price_date is before 2010
    data['price_date'] = pd.to_datetime(data['price_date'], format='%Y-%m-%d', errors='coerce')
    data = data[data['price_date'].dt.year >= 2010]
    
    # Create a 'quarter' column
    data['quarter'] = data['price_date'].dt.year.astype(str) + '-Q' + data['price_date'].dt.quarter.astype(str)
    
    # Group the data by 'fund_symbol' and 'quarter' and calculate the metrics
    aggregated_df = data.groupby(['fund_symbol', 'quarter']).agg(
        avg_volume=('volume', 'mean'),
        high=('high', 'max'),
        low=('low', 'min'),
        quarter_open=('open', 'first'),
        quarter_close=('close', 'last'),
        price_average=('close', 'mean')
    ).reset_index()
    
    # Calculate ROI and absolute return
    aggregated_df['roi'] = ((aggregated_df['quarter_close'] - aggregated_df['quarter_open']) / aggregated_df['quarter_open']) * 100
    aggregated_df['absolute_return'] = aggregated_df['quarter_close'] - aggregated_df['quarter_open']
    
    # Sort the result by 'fund_symbol' and 'quarter'
    ordered_result_df = aggregated_df.sort_values(by=['fund_symbol', 'quarter'])
    
    # Convert the final result to CSV and write it back to S3
    csv_buffer = io.StringIO()
    ordered_result_df.to_csv(csv_buffer, index=False)
    
    # Upload the result to S3
    s3.put_object(Bucket=bucket_name, Key=f'{output_prefix}etf_price_analysis.csv', Body=csv_buffer.getvalue())
    
    
    # Save the raw CSV to output_prefix
    csv_buffer = io.StringIO()
    data.to_csv(csv_buffer, index=False)
    s3.put_object(Bucket=bucket_name, Key=f'{output_prefix}etf_prices_raw.csv', Body=csv_buffer.getvalue())
    
    return {"status": "Data processed and stored successfully."}
