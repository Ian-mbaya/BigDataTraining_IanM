import json
import boto3
import psycopg2
import os
from datetime import datetime

# Initialize the S3 client
s3 = boto3.client('s3')

# Database credentials (set these as environment variables or hardcode them for testing)
DB_HOST = 'ec2-18-132-73-146.eu-west-2.compute.amazonaws.com'
DB_USER = 'consultants'
DB_PASSWORD = 'WelcomeItc@2022'
DB_NAME = 'testdb'

# Define the S3 folder for etf data
ETF_DATA_FOLDER = 'rawbronze/etfdata'

# Last known timestamp for incremental load
LAST_TIMESTAMP = '2024-10-23 16:59:17.676221' #NEXT TIMESTAMP' 2024-10-23 17:05:05.676221

# Custom JSON encoder for datetime objects
class DateTimeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            # Convert datetime to string in ISO format
            return obj.isoformat()
        return super().default(obj)

# Connect to the external PostgreSQL database
def connect_to_db():
    connection = psycopg2.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        dbname=DB_NAME,
        port=5432  # Default PostgreSQL port
    )
    return connection

def fetch_incremental_etf_data(connection, last_timestamp):
    with connection.cursor() as cursor:
        # Query to fetch records from the 'awsetfs' table with timestamp greater than the last known timestamp
        cursor.execute(f"SELECT * FROM awsetfs WHERE timestamp > %s", (last_timestamp,))
        result = cursor.fetchall()
    return result

def upload_to_s3(bucket_name, folder, records, table_name):
    # Convert records to JSON format with custom datetime handling
    file_content = json.dumps(records, cls=DateTimeEncoder)
    # Define the S3 key (file path)
    s3_key = f'{folder}/{table_name}_data_{datetime.now().strftime("%Y%m%d%H%M%S")}.json'
    # Upload the file to S3
    s3.put_object(Bucket=bucket_name, Key=s3_key, Body=file_content)

def lambda_handler(event, context):
    # S3 bucket name from environment variable or hard-code it
    bucket_name = os.environ.get('BUCKET_NAME', 'ian5774')

    # Connect to the external PostgreSQL database
    connection = connect_to_db()

    # Fetch incremental records from the 'awsetfs' table based on the last timestamp
    awsetfs_records = fetch_incremental_etf_data(connection, LAST_TIMESTAMP)

    # Upload records from 'awsetfs' table to the 'rawbronze/etfdata/' folder in S3
    if awsetfs_records:
        upload_to_s3(bucket_name, ETF_DATA_FOLDER, awsetfs_records, 'awsetfs')
    else:
        print('No new records to upload.')

    # Close the database connection
    connection.close()

    return {
        'statusCode': 200,
        'body': json.dumps('Data uploaded successfully!' if awsetfs_records else 'No new data to upload.')
    }
