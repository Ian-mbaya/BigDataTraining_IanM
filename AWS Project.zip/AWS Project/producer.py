import json
import random
import math
import boto3
from dataclasses import dataclass
from enum import Enum
from typing import List
from threading import Lock

# Initialize the Kinesis client
kinesis_client = boto3.client('kinesis', region_name='us-east-1')  

class TradeType(Enum):
    BUY = "BUY"
    SELL = "SELL"

@dataclass
class FundPrice:
    ticker_symbol: str
    price: float

@dataclass
class FundTrade:
    ticker_symbol: str
    trade_type: TradeType
    price: float
    quantity: int
    trade_id: int

class TradeIDGenerator:
    def __init__(self):
        self.id = 1
        self.lock = Lock()

    def get_next_id(self):
        with self.lock:
            trade_id = self.id
            self.id += 1
        return trade_id

class FundTradeGenerator:
    FUND_PRICES: List[FundPrice] = [
        FundPrice("ADRE", 8.27),
        FundPrice("DIA", 47.42),
        FundPrice("EFA", 25.58),
        FundPrice("EWZ", 10.50),
        FundPrice("IBB", 33.52),
        FundPrice("IEV", 22.24),
        FundPrice("IGN", 31.70),
        FundPrice("IJT", 16.62),
        FundPrice("IUSV", 14.90),
        FundPrice("QQQ", 44.34),
    ]

    MAX_DEVIATION = 0.2
    MAX_QUANTITY = 10000
    PROBABILITY_SELL = 0.4

    def __init__(self):
        self.random = random.Random()
        self.trade_id_generator = TradeIDGenerator()

    def get_random_trade(self) -> FundTrade:
        fund_price = random.choice(self.FUND_PRICES)
        deviation = (self.random.random() - 0.5) * 2.0 * self.MAX_DEVIATION
        price = fund_price.price * (1 + deviation)
        price = math.floor(price * 100) / 100

        trade_type = TradeType.BUY
        if self.random.random() < self.PROBABILITY_SELL:
            trade_type = TradeType.SELL

        quantity = self.random.randint(1, self.MAX_QUANTITY)
        trade_id = self.trade_id_generator.get_next_id()

        return FundTrade(fund_price.ticker_symbol, trade_type, price, quantity, trade_id)

    def send_to_kinesis(self, trade: FundTrade, stream_name: str):
        """Send a trade record to the Kinesis Data Stream."""
        try:
            data = {
                "trade_id": trade.trade_id,
                "ticker_symbol": trade.ticker_symbol,
                "trade_type": trade.trade_type.value,
                "price": trade.price,
                "quantity": trade.quantity
            }
            # Send record to Kinesis
            response = kinesis_client.put_record(
                StreamName=stream_name,
                Data=json.dumps(data),
                PartitionKey=trade.ticker_symbol  # Partition key is the ticker symbol
            )
            print(f"Successfully sent trade {trade.trade_id} to Kinesis: {response}")
        except Exception as e:
            print(f"Failed to send trade to Kinesis: {e}")

def lambda_handler(event, context):
    stream_name = 'stockprice'  
    generator = FundTradeGenerator()

    # Generate a trade and send it to the Kinesis stream
    trade = generator.get_random_trade()
    generator.send_to_kinesis(trade, stream_name)

    # Prepare the trade data for the response (convert to a serializable format)
    trade_data = {
        "trade_id": trade.trade_id,
        "ticker_symbol": trade.ticker_symbol,
        "trade_type": trade.trade_type.value,
        "price": trade.price,
        "quantity": trade.quantity
    }

    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Trade sent to Kinesis", "trade": trade_data})
    }

