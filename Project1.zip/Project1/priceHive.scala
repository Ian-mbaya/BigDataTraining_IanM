package project.etf

import org.apache.spark.sql.SparkSession

object priceHive extends App {
  // Create a Spark session with Hive support
  val spark = SparkSession.builder()
    .appName("priceToHive")
    .config("spark.hadoop.fs.defaultFS", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022")
    .config("spark.sql.warehouse.dir", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/user/hive/warehouse")
    .config("hive.metastore.uris", "thrift://ip-172-31-1-36.eu-west-2.compute.internal:9083") // Specify Hive Metastore URI
    .enableHiveSupport() // Enable Hive support
    .getOrCreate()

  // Drop the existing Hive table if it exists
  spark.sql("DROP TABLE IF EXISTS etf.fund_analysis")

  // SQL statement to create the Hive external table for fund analysis
  val createTableQuery =
    """
      |CREATE EXTERNAL TABLE IF NOT EXISTS etf.fund_analysis (
      |  fund_symbol STRING,
      |  quarter STRING,
      |  avg_volume DOUBLE,
      |  high DOUBLE,
      |  low DOUBLE,
      |  quarter_open DOUBLE,
      |  quarter_close DOUBLE,
      |  price_average DOUBLE,
      |  roi DOUBLE,
      |  absolute_return DOUBLE
      |)
      |STORED AS PARQUET
      |LOCATION '/tmp/ian/project/HIVE_analysis'
      |""".stripMargin

  // Execute the create table statement
  spark.sql(createTableQuery)

  // Path to the HDFS directory where the data is stored
  val inputFilePath = "/tmp/ian/project/fund_analysis"

  // Read the data from HDFS (it's in a CSV format)
  val etfDF = spark.read
    .option("header", "true")
    .option("inferSchema", "true")
    .csv(inputFilePath)

  // Write the DataFrame to the Hive external table
  etfDF
    .write
    .mode("append")
    .insertInto("etf.fund_analysis")

  // Stop the Spark session
  spark.stop()
}
