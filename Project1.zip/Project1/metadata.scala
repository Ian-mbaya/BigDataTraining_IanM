package project.etf

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object metadata extends App{

    // Create a Spark session with Hive support
    val spark = SparkSession.builder()
      .appName("CombinedMetadataToHive")
      .config("spark.hadoop.fs.defaultFS", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022")
      .config("spark.sql.warehouse.dir", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/user/hive/warehouse")
      .config("hive.metastore.uris", "thrift://ip-172-31-1-36.eu-west-2.compute.internal:9083") // Specify Hive Metastore URI
      .config("spark.sql.legacy.timeParserPolicy", "LEGACY") // Use legacy time parser
      .enableHiveSupport() // Enable Hive support
      .getOrCreate()

    // Define the path to read the Parquet file
    val etfInputFilePath = "/tmp/ian/project/etf_data/"

    // Read the Parquet file from HDFS
    val etfDF = spark.read.parquet(etfInputFilePath).coalesce(1)

    // Extract the Fund Metadata table
    val fundMetadataDF = etfDF.select(
      col("fund_symbol"),
      col("fund_long_name"),
      col("fund_family"),
      col("exchange_name"),
      col("total_net_assets"),
    )

    // Define the path for the Fund Metadata table in HDFS
    val fundMetadataPath = "/tmp/ian/project/fund_metadata"

    // Write the Fund Metadata DataFrame to HDFS in Parquet format
    fundMetadataDF.write
      .mode("overwrite")
      .parquet(fundMetadataPath)

    // Drop the existing Hive table if it exists
    spark.sql("DROP TABLE IF EXISTS etf.metadata")

    // SQL statement to create the Hive external table for fund metadata in the 'etf' database
    val createTableQuery =
      """
        |CREATE EXTERNAL TABLE IF NOT EXISTS etf.metadata (
        |  fund_symbol STRING,
        |  fund_long_name STRING,
        |  fund_family STRING,
        |  exchange_name STRING,
        |  total_net_assets BIGINT
        |)
        |STORED AS PARQUET
        |LOCATION '/tmp/ian/project/HIVE_metadata'
        |""".stripMargin

    // Execute the create table statement
    spark.sql(createTableQuery)

    // Read the data from the Parquet file in HDFS
    val fundMetadataReadDF = spark.read.parquet(fundMetadataPath)

    // Write the DataFrame to the Hive table
    fundMetadataReadDF
      .write
      .mode("append")
      .insertInto("etf.metadata")

    // Stop the Spark session
    spark.stop()

}
