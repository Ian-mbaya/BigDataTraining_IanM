package project.etf

import org.apache.spark.sql.SparkSession

object parquet extends App{
  // Initialize Spark session
  // Create a Spark session
  val spark = SparkSession.builder()
    .appName("FundMetadataCreation")
    .config("spark.hadoop.fs.defaultFS", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022")
    .config("spark.sql.legacy.timeParserPolicy", "LEGACY")
    .getOrCreate()

  // Read the CSV file from HDFS
  val etfDF = spark.read
    .option("inferSchema", "true")
    .option("header", "true")
    .csv("/tmp/ian/project/etfdata/")

  // Define the HDFS output path for the Investment Strategy table
  val etfParquetPath = "/tmp/ian/project/etf_data"

  // Write the Investment Strategy DataFrame to HDFS in Parquet format
  etfDF.write
    .mode("overwrite") // Overwrite mode to replace existing data
    .parquet(etfParquetPath)
  //Stop the Spark session
  spark.stop()


}
