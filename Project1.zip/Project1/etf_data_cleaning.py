import pandas as pd
from datetime import datetime, timedelta

# Load the tab-delimited data
df = pd.read_csv('raw\\etf_data.txt', sep='\t')

## columns to keep
import pandas as pd

# Defining the column names based on the provided string values
import pandas as pd

columns_to_keep = [
    "fund_symbol",
    "fund_long_name",
    "fund_category",
    "fund_family",
    "exchange_code",
    "exchange_name",
    "avg_vol_3month",
    "total_net_assets",
    "investment_strategy",
    "fund_yield",
    "inception_date",
    "investment_type",
    "size_type",
    "fund_price_earning_ratio",
    "fund_price_sales_ratio",
    "top10_holdings_total_assets",
    "fund_return_ytd",
    "fund_return_3years",
    "fund_return_10years",
    "top10_holdings"
]



# Drop all other columns
df = df[columns_to_keep]

# Display the new DataFrame
print(df.shape)

# Remove quotes from the 'investment_strategy' column and replace commas with hyphens
df['investment_strategy'] = df['investment_strategy'].str.replace('"', '').str.replace(',', ' -')

holdings_expanded = pd.DataFrame()

for index, row in df.iterrows():
    # Check if 'top10_holdings' is a string; if not, skip to the next row
    if isinstance(row['top10_holdings'], str):
        # Remove unnecessary characters from 'top10_holdings'
        holdings = row['top10_holdings'].replace('"', '').replace('(', '').replace(')', '')
        # Split by comma to get key-value pairs
        pairs = holdings.split(', ')
        
        # Limit to only the first 10 pairs
        pairs = pairs[:10]
        
        # Create columns for each holding
        for i, pair in enumerate(pairs):
            # Only process pairs that contain ': '
            if ': ' in pair:
                key, value = pair.split(':')
                holdings_expanded.at[index, f'holding{i+1}_name'] = key.strip()
                holdings_expanded.at[index, f'holding{i+1}_value'] = float(value.strip())
            # Skip pairs that don't match the pattern
            else:
                continue
    else:
        # Optionally log or handle the case where top10_holdings is NaN or not a string
        print(f"Skipping row {index} due to non-string value in 'top10_holdings': {row['top10_holdings']}")


# Combine the expanded holdings with the original DataFrame
df = pd.concat([df, holdings_expanded], axis=1)

# Drop the original 'top10_holdings' column
df.drop(columns=['top10_holdings'], inplace=True)


# Introduce consecutive timestamps starting from now
start_time = datetime.now()
time_interval = timedelta(seconds=12)
df['timestamp'] = [start_time + i * time_interval for i in range(len(df))]

# Save the processed DataFrame to a new CSV
df.to_csv('staged\\clean_etfs.csv', index=False, sep=",")
