import pandas as pd
from sqlalchemy import create_engine

# Load the CSV file into a DataFrame
# Load the CSV file into a DataFrame
csv_file_path = 'staged\\batch\\etfs_3.csv'
df = pd.read_csv(csv_file_path)

# Database connection parameters
username = 'consultants'
password = 'WelcomeItc%402022' 
database = 'testdb'
host = 'ec2-18-132-73-146.eu-west-2.compute.amazonaws.com'


# Create the SQLAlchemy engine
engine = create_engine(f'postgresql://{username}:{password}@{host}/{database}')

# Coerce 'inception_date' and 'timestamp' columns to datetime format
if 'inception_date' in df.columns:
    df['inception_date'] = pd.to_datetime(df['inception_date'], errors='coerce')
    
if 'timestamp' in df.columns:
    df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')

# Insert the data into the existing 'etfs' table
try:
    df.to_sql('etfs', engine, if_exists='append', index=False)
    print("Data inserted into the etfs table successfully.")
except Exception as e:
    print(f"An error occurred: {e}")
