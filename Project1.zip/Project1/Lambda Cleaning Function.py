import boto3
import pandas as pd
import io

def lambda_handler(event, context):
    # Initialize S3 client
    s3 = boto3.client('s3')
    bucket_name = 'ian5774'  
    input_prefix = 'rawbronze/toprocess'   
    holdings_folder = 'stagingsilver/holdings/'     
    etf_transformed = 'stagingsilver/etfTransformed/'  
    
    # Get list of objects in the specified S3 folder
    response = s3.list_objects_v2(Bucket=bucket_name, Prefix=input_prefix)
    if 'Contents' not in response:
        return {"status": "No files found in the specified S3 folder."}

    # Read the data files
    dataframes = []
    for obj in response['Contents']:
        file_key = obj['Key']
        if file_key.endswith('.csv'):
            file_obj = s3.get_object(Bucket=bucket_name, Key=file_key)
            df = pd.read_csv(io.BytesIO(file_obj['Body'].read()))
            dataframes.append(df)
    
    # Concatenate all dataframes
    data = pd.concat(dataframes, ignore_index=True)
    
    # Initialize an empty DataFrame for the holdings
    holdings_df = []

    # Determine the maximum number of holdings
    max_holdings = 10

    # Loop through the possible holdings
    for i in range(1, max_holdings + 1):
        name_col = f'holding{i}_name'
        value_col = f'holding{i}_value'
    
        # Check if the name and value columns exist in the DataFrame
        if name_col in data.columns and value_col in data.columns:
            # Create a temporary DataFrame for current holdings
            temp_holdings = data[[name_col, value_col]].copy()
        
            # Add fund_symbol column to the temporary DataFrame
            temp_holdings['fund_symbol'] = data['fund_symbol']
        
            # Rename the columns to fund_name and fund_value
            temp_holdings.columns = ['fund_name', 'fund_value', 'fund_symbol']
        
            # Append the temporary holdings DataFrame to the list
            holdings_df.append(temp_holdings)

    # Concatenate all the temporary DataFrames into a single holdings DataFrame
    #holdings_df = pd.concat(holdings_df, ignore_index=True)

    # Drop rows where fund_name or fund_value is null
    holdings_df = holdings_df.dropna(subset=['fund_name', 'fund_value'])

    # Reorder the columns as required
    holdings_df = holdings_df[['fund_symbol', 'fund_name', 'fund_value']]

    # Get the list of columns from the holdings DataFrame
    columns_to_drop = list(holdings_df.columns)

    # Remove 'fund_symbol' from the list if it exists
    if 'fund_symbol' in columns_to_drop:
        columns_to_drop.remove('fund_symbol')

    # Drop these columns from the data DataFrame
    etfdata = data.drop(columns=columns_to_drop)

   

    # Write holdings dataframe to S3
    holdings_csv_buffer = io.StringIO()
    holdings_df.to_csv(holdings_csv_buffer, index=False)
    s3.put_object(Bucket=bucket_name, Key=f'{holdings_folder}holdings_data.csv', Body=holdings_csv_buffer.getvalue())

    # Write etfdata dataframe to S3
    etfdata_csv_buffer = io.StringIO()
    etfdata.to_csv(etfdata_csv_buffer, index=False)
    s3.put_object(Bucket=bucket_name, Key=f'{etf_transformed}etf_data.csv', Body=etfdata_csv_buffer.getvalue())

    return {"status": "Data processed and stored successfully."}

