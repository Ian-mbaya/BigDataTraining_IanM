from datetime import datetime
from airflow.utils.dates import days_ago
from airflow import DAG
from airflow.operators.bash_operator import BashOperator

dag = DAG('etf_processing_dag', description='ETL DAG for ETF Processing', start_date=days_ago(1), catchup=False)

# Define tasks to run the Python scripts directly
data_cleaning_task = BashOperator(
    task_id='etf_data_cleaning',
    bash_command='python /home/ec2-user/airflow/dags/etf/etf_data_cleaning.py',
    dag=dag,
)

price_cleaning_task = BashOperator(
    task_id='etf_price_cleaning',
    bash_command='python /home/ec2-user/airflow/dags/etf/etf_price_cleaning.py',
    dag=dag,
)

batching_task = BashOperator(
    task_id='batching',
    bash_command='python /home/ec2-user/airflow/dags/etf/batching.py',
    dag=dag,
)

# Setting up task dependencies to run them sequentially
data_cleaning_task >> price_cleaning_task >> batching_task
