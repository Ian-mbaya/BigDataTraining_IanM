package project.etf

import org.apache.spark.sql.functions.{col, lit, struct, udf}
import org.apache.spark.sql.{Row, SparkSession}

object fund_holdings extends App {

  // Create a Spark session with Hive support and necessary configurations
  val spark = SparkSession.builder()
    .appName("ParquetToHiveHoldings")
    .config("spark.hadoop.fs.defaultFS", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022")
    .config("spark.sql.warehouse.dir", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/user/hive/warehouse")
    .config("hive.metastore.uris", "thrift://ip-172-31-1-36.eu-west-2.compute.internal:9083")
    .config("spark.sql.legacy.timeParserPolicy", "LEGACY")
    .enableHiveSupport()
    .getOrCreate()


  // Drop the existing Hive table if it exists
  spark.sql("DROP TABLE IF EXISTS etf.fund_holdings")

  // SQL statement to create the external Hive table for parsed holdings data
  val createTableQuery =
    """
      |CREATE EXTERNAL TABLE IF NOT EXISTS etf.fund_holdings (
      |  fund_symbol STRING,
      |  holdings MAP<STRING, DOUBLE>
      |)
      |STORED AS PARQUET
      |LOCATION '/tmp/ian/project/HIVE_holdings'
      |""".stripMargin

  // Execute the create table statement
  spark.sql(createTableQuery)

  // Path to the HDFS directory where the Parquet file is stored
  val inputFilePath = "/tmp/ian/project/etf_data"

  // Read the Parquet file from HDFS
  val etfDF = spark.read.parquet(inputFilePath).coalesce(1)

  // Function to create a map of holdings from columns holding1_name, holding1_value, etc.
  def createHoldingsMap(row: Row): Map[String, Double] = {
    (1 to 10).flatMap { i =>
      val name = row.getAs[String](s"holding${i}_name")
      val value = row.getAs[Double](s"holding${i}_value")
      if (name != null && value != null) {
        Some(name -> value)
      } else {
        None
      }
    }.toMap + ("otherHoldings" -> (1.0 - row.getAs[Double]("top10_holdings_total_assets")))
  }

  // UDF to convert each row into a Map[String, Double] for holdings
  val createHoldingsMapUDF = udf(createHoldingsMap _)

  // Add a new column with the holdings map
  val parsedHoldingsDF = etfDF
    .withColumn("holdings", createHoldingsMapUDF(struct(etfDF.columns.map(col): _*)))
    .select("fund_symbol", "holdings")

  // Define the HDFS output path for the Parquet file
  val holdingsPath = "/tmp/ian/project/fund_holdings"

  // Write the resulting DataFrame to HDFS in Parquet format
  parsedHoldingsDF
    .write
    .mode("overwrite") // Overwrite mode to replace existing data
    .parquet(holdingsPath)

  // Write the DataFrame to the external Hive table
  parsedHoldingsDF
    .write
    .mode("append")
    .insertInto("etf.fund_holdings")

  // Stop the Spark session
  spark.stop()
}
