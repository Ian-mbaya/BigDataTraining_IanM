package project.etf

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col

object strategy extends App{

    // Create a Spark session with Hive support
    val spark = SparkSession.builder()
      .appName("strategyToHive")
      .config("spark.hadoop.fs.defaultFS", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022")
      .config("spark.sql.warehouse.dir", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/user/hive/warehouse")
      .config("hive.metastore.uris", "thrift://ip-172-31-1-36.eu-west-2.compute.internal:9083") // Specify Hive Metastore URI
      .enableHiveSupport() // Enable Hive support
      .getOrCreate()

    // Drop the existing table if it exists
    spark.sql("DROP TABLE IF EXISTS etf.fund_strategy")

    // SQL statement to create the external Hive table for investment strategy
    val createTableQuery =
      """
        |CREATE EXTERNAL TABLE IF NOT EXISTS etf.fund_strategy (
        |  fund_symbol STRING,
        |  fund_category STRING,
        |  investment_type STRING,
        |  size_type STRING,
        |  investment_strategy STRING
        |)
        |STORED AS PARQUET
        |LOCATION '/tmp/ian/project/HIVE_strategy'
        |""".stripMargin

    // Execute the creatTableQuery statement
    spark.sql(createTableQuery)

    // Path to the HDFS directory where the Parquet file is stored
    val inputFilePath = "/tmp/ian/project/etf_data"

    // Read the data from the Parquet file in HDFS
    val etfDF = spark.read.parquet(inputFilePath)

    // Select and cast the required columns
    val fundStrategyDF = etfDF.select(
      col("fund_symbol"),
      col("fund_category"),
      col("investment_type"),
      col("size_type"),
      col("investment_strategy").cast("STRING")
    )

    // Write the DataFrame to the Hive table
    try {
      fundStrategyDF
        .write
        .mode("append")
        .insertInto("etf.fund_strategy")
    } catch {
      case e: Exception => println(s"Error while writing to Hive: ${e.getMessage}")
    }

    // Stop the Spark session
    spark.stop()
  }
