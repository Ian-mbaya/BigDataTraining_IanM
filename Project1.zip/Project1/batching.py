import pandas as pd

# Load your datasets
etfs = pd.read_csv("staged\\etfs.csv")
prices = pd.read_csv("staged\\prices.csv")

# Split 'etfs' into 5 batches of 7 rows each
etfs_batches = [etfs.iloc[i:i+7] for i in range(0, len(etfs), 7)]

# Function to filter 'prices' based on fund_symbols in a batch of 'etfs'
def filter_prices_by_etfs_batch(etfs_batch, prices_df):
    fund_symbols = etfs_batch['fund_symbol'].tolist()  
    return prices_df[prices_df['fund_symbol'].isin(fund_symbols)]

# Iterate over each etfs batch and create corresponding prices batch
for i, etfs_batch in enumerate(etfs_batches):
    # Filter prices for the current etfs batch
    prices_batch = filter_prices_by_etfs_batch(etfs_batch, prices)
    
    # Save the etfs batch
    etfs_batch.to_csv(f"staged\\batch\\etfs_{i+1}.csv", index=False)
    
    # Save the corresponding prices batch
    prices_batch.to_csv(f"staged\\batch\\prices_{i+1}.csv", index=False)

print("Batches have been created and saved as CSV files.")
