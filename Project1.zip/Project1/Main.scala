package project.etf

import org.apache.spark.sql.SparkSession

object Main {
  def main(args: Array[String]): Unit = {

/// the schema of the DataFrame to verify the connection

  }
}
