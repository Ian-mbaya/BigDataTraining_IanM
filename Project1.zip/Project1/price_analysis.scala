package project.etf

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object price_analysis extends App {

  // Create a Spark session
  val spark = SparkSession.builder()
    .appName("ETFQuarterlyAnalysis")
    //.master("local[*]") // Remember to remove before running on the cluster
    .config("spark.hadoop.fs.defaultFS", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022")
    .config("spark.sql.legacy.timeParserPolicy", "LEGACY") // Use legacy time parser
    .getOrCreate()

  // Read the CSV file
  val inputFilePath = "/tmp/ian/project/etf_prices/"

  // Specify the expected schema (column names) if the CSV does not have headers
  val columnNames = Seq("fund_symbol", "price_date", "open", "high", "low", "close", "adj_close", "volume")

  // Read the CSV file without header and assign custom column names
  val etfDF = spark.read
    .option("header", "false") // Indicate that the CSV does not have headers
    .option("inferSchema", "true")
    .csv(inputFilePath)
    .toDF(columnNames: _*) // Assign custom column names

  // Convert the price_date to a proper date format using the correct format and create a quarter column
  val etfWithQuarter = etfDF.withColumn("price_date", to_date(col("price_date"), "yyyy-MM-dd"))
    .withColumn("quarter", concat(year(col("price_date")), lit("-Q"), quarter(col("price_date"))))

  // Display a few rows to verify if price_date and quarter are populated correctly
  etfWithQuarter.show(10)

  // Group the data by fund_symbol and quarter to calculate the required metrics
  val aggregatedDF = etfWithQuarter
    .groupBy("fund_symbol", "quarter")
    .agg(
      avg("volume").alias("avg_volume"),
      max("high").alias("high"),
      min("low").alias("low"),
      first("open").alias("quarter_open"),
      last("close").alias("quarter_close"),
      avg("close").alias("price_average") // Calculate the average close price
    )

  // Calculate ROI and absolute return based on the quarter_open and quarter_close
  val finalResultDF = aggregatedDF
    .withColumn("roi", expr("(quarter_close - quarter_open) / quarter_open * 100")) // ROI calculation based on open
    .withColumn("absolute_return", expr("quarter_close - quarter_open"))             // Absolute return calculation based on open

  // Order the final result by fund_symbol and quarter
  val orderedResultDF = finalResultDF.orderBy("fund_symbol", "quarter")

  // Show the sorted DataFrame to verify the ordering
  orderedResultDF.show(10)

  // Path to HDFS for the output
  val outputFilePath = "/tmp/ian/project/fund_analysis"

  // Write the result to a new CSV file
  orderedResultDF.coalesce(1).write.mode("overwrite").option("header", "true").csv(outputFilePath)

  // Stop the Spark session
  spark.stop()
}
