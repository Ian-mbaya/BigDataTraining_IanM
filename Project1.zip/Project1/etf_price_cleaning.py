import pandas as pd
# Read Original ETF data (meta data)
etfs = pd.read_csv('staged\\clean_etfs.csv', sep=',')
prices = pd.read_csv('raw\\ETFprices.csv', sep=',')



# Step 1: Filter out rows from 'etfs' DataFrame where 'fund_return_10years' is null
etfs = etfs[~etfs['fund_return_10years'].isnull()]

# Step 2: Filter out rows from 'etfs' DataFrame where 'fund_price_earning_ratio' is null
etfs = etfs[~etfs['fund_price_earning_ratio'].isnull()]

# Check the remaining rows after deletion
print(f"Remaining rows in etfs: {etfs.shape}")

# Step 3: Remove corresponding rows from 'prices' DataFrame
# Get the remaining fund symbols in 'etfs' after the above filtering
remaining_fund_symbols = etfs['fund_symbol'].tolist()

# Filter 'prices' DataFrame to include only rows with 'fund_symbol' present in 'remaining_fund_symbols'
prices = prices[prices['fund_symbol'].isin(remaining_fund_symbols)]

# Check the remaining rows after deletion
print(f"Remaining rows in prices: {prices.shape}")


# Group by 'fund_symbol' and count the occurrences in the 'prices' DataFrame
fund_counts = prices.groupby('fund_symbol').size().reset_index(name='count')

# Calculate the 90th percentile of the counts
percentile_90 = fund_counts['count'].quantile(0.90)

# Filter funds that have a count >= the 90th percentile
top_funds = fund_counts[fund_counts['count'] >= percentile_90]

# Filter 'prices' and 'etfs' to keep only fund_symbols that are in 'top_funds'
filtered_prices = prices[prices['fund_symbol'].isin(top_funds['fund_symbol'])]
filtered_etfs = etfs[etfs['fund_symbol'].isin(top_funds['fund_symbol'])]

# Optional: Checking the results
print(f"Filtered prices DataFrame shape: {filtered_prices.shape}")
print(f"Filtered etfs DataFrame shape: {filtered_etfs.shape}")


#Write to CSV
filtered_prices.to_csv('staged\\prices.csv', sep=',', index=False)
filtered_etfs.to_csv('staged\\etfs.csv', sep=',', index=False)

